#include <iostream>
#include "Tfigura.h"
#include "Tkolo.h"
#include "Tprostokat.h"
#include "Tkwadrat.h"
#include "Ifigura.h"
#include "Tkolo2.h"
#include "Tprostokat2.h"
#include "Tkwadrat2.h"

using namespace std;

int main()
{
    //Zadanie 6.2 Polimorfizm
    /*Tfigura figura;
    figura.wyswietl();
    cout<<endl;
    Tkolo kolo;
    kolo.wyswietl();
    cout<<endl;
    Tprostokat prostokat;
    prostokat.wyswietl();
    cout<<endl;
    Tkwadrat kwadrat;
    kwadrat.wyswietl();*/

    //Zadanie 6.3 Klasa abstrakcyjna
    Tkolo2 kolo2;
    Tprostokat2 prostokat2;
    Tkwadrat2 kwadrat2;

    Ifigura *wsk;
    wsk = &kolo2;
    wsk -> wyswietl();
    cout<<endl;
    wsk = &prostokat2;
    wsk -> wyswietl();
    cout<<endl;
    wsk = &kwadrat2;
    wsk -> wyswietl();
    return 0;
}
