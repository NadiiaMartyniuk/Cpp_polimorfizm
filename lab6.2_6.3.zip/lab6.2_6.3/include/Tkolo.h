#ifndef TKOLO_H
#define TKOLO_H
#include "Tfigura.h"
#include<string>
#include <iostream>
using namespace std;
class Tkolo: public Tfigura
{
    public:
        Tkolo();
        Tkolo(string n, float rr);
        virtual ~Tkolo();
        float pole();
        float obwod();

    protected:

    private:
        float r;
};

#endif // TKOLO_H
