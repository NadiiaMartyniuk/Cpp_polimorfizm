#ifndef TKOLO2_H
#define TKOLO2_H
#include "Ifigura.h"
#include<string>
#include <iostream>
using namespace std;
class Tkolo2 : public Ifigura
{
    public:
        Tkolo2();
        Tkolo2(string n, float rr);
        virtual ~Tkolo2();
        float pole();
        float obwod();

    protected:
        float r;

    private:
};

#endif // TKOLO2_H
