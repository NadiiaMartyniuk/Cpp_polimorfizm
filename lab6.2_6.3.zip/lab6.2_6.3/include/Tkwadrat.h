#ifndef TKWADRAT_H
#define TKWADRAT_H
#include "Tfigura.h"
#include<string>
#include <iostream>
#include "Tprostokat.h"

class Tkwadrat: public Tprostokat
{
    public:
        Tkwadrat();
        virtual ~Tkwadrat();
        Tkwadrat(string naz, float a1);
    protected:

    private:
};

#endif // TKWADRAT_H
