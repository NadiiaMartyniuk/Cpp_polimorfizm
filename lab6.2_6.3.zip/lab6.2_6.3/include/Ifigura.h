#ifndef IFIGURA_H
#define IFIGURA_H
#include<string>
#include <iostream>
using namespace std;
class Ifigura
{
    public:
        void rysuj();
        void info();
        virtual float pole()=0;
        virtual float obwod()=0;
        void wyswietl();
    protected:
        string nazwa;

    private:
};

#endif // IFIGURA_H
