#ifndef TPROSTOKAT_H
#define TPROSTOKAT_H
#include "Tfigura.h"
#include<string>
#include <iostream>

class Tprostokat: public Tfigura
{
    public:
        Tprostokat();
        Tprostokat(string n, float aa, float bb);
        virtual ~Tprostokat();
        float pole();
        float obwod();
    protected:
        float a,b;
    private:

};

#endif // TPROSTOKAT_H
