#ifndef TPROSTOKAT2_H
#define TPROSTOKAT2_H
#include "Ifigura.h"
#include<string>
#include <iostream>
using namespace std;

class Tprostokat2 : public Ifigura
{
    public:
        Tprostokat2();
        Tprostokat2(string n, float aa, float bb);
        virtual ~Tprostokat2();
        float pole();
        float obwod();
    protected:
        float a,b;

    private:
};

#endif // TPROSTOKAT2_H
