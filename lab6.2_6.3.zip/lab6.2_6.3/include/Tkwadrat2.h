#ifndef TKWADRAT2_H
#define TKWADRAT2_H
#include "Ifigura.h"
#include<string>
#include <iostream>
#include "Tprostokat2.h"

class Tkwadrat2: public Tprostokat2
{
    public:
        Tkwadrat2();
        virtual ~Tkwadrat2();
        Tkwadrat2(string naz, float a1);
    protected:

    private:
};

#endif // TKWADRAT2_H
