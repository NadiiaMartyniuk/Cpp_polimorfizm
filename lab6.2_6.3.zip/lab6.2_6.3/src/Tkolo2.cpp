#include "Tkolo2.h"
#include<string>
#include <iostream>
Tkolo2::Tkolo2()
{
    nazwa = "kolo";
    r=1;
}

Tkolo2::Tkolo2(string n, float rr){
    nazwa=n;
    r=rr;
}

Tkolo2::~Tkolo2()
{
    //dtor
}

float Tkolo2::pole(){
    return 3.14*r*r;
}

float Tkolo2::obwod(){
    return 2*3.14*r;
}

