#include "Tkwadrat.h"

Tkwadrat::Tkwadrat()
{
    nazwa="kwadrat";
    a=3;
    b=a;
}

Tkwadrat::~Tkwadrat()
{
    //dtor
}

Tkwadrat::Tkwadrat(string naz, float a1){
    nazwa=naz;
    a=a1;
    b=a1;
}
