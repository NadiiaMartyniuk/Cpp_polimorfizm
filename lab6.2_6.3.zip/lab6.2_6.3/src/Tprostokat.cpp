#include "Tprostokat.h"

Tprostokat::Tprostokat()
{
    nazwa="prostokat";
    a=1;
    b=2;
}

Tprostokat::~Tprostokat()
{
    //dtor
}

Tprostokat::Tprostokat(string n, float aa, float bb){
    nazwa=n;
    a=aa;
    b=bb;
}

float Tprostokat::pole(){
    return a*b;
}

float Tprostokat::obwod(){
    return a+b;
}

