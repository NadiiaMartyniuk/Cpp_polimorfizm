#include "Tfigura.h"
#include "Tkolo.h"
#include<string>
#include <iostream>
using namespace std;
Tkolo::Tkolo()
{
    nazwa="kolo";
    r=1;
}

Tkolo::Tkolo(string n, float rr)
{
    nazwa=n;
    r=rr;
}

Tkolo::~Tkolo()
{
    //dtor
}

float Tkolo::pole(){
    return 3.14*r*r;
}

float Tkolo::obwod(){
    return 2*3.14*r;
}


