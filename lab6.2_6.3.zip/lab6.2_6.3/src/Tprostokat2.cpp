#include "Tprostokat2.h"

Tprostokat2::Tprostokat2()
{
    nazwa="prostokat";
    a=1;
    b=2;
}

Tprostokat2::~Tprostokat2()
{
    //dtor
}

Tprostokat2::Tprostokat2(string n, float aa, float bb){
    nazwa=n;
    a=aa;
    b=bb;
}

float Tprostokat2::pole(){
    return a*b;
}

float Tprostokat2::obwod(){
    return a+b;
}

