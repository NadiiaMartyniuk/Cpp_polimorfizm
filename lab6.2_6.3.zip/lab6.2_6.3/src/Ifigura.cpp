#include "Ifigura.h"

void Ifigura::info(){
    cout<<"Figura : "<<nazwa<<endl;
}

void Ifigura::rysuj(){
    cout<<"rysuje "<<nazwa<<endl;
}

void Ifigura::wyswietl(){
    info();
    rysuj();
    cout<<"Pole = "<<pole()<<endl;
    cout<<"Obwod = "<<obwod()<<endl;
}
