#include "Tkwadrat2.h"

Tkwadrat2::Tkwadrat2()
{
    nazwa="kwadrat";
    a=3;
    b=a;
}

Tkwadrat2::~Tkwadrat2()
{
    //dtor
}

Tkwadrat2::Tkwadrat2(string naz, float a1){
    nazwa=naz;
    a=a1;
    b=a1;
}
