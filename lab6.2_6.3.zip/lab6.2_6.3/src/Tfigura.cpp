#include "Tfigura.h"
#include <iostream>
using namespace std;
Tfigura::Tfigura()
{
    nazwa="figura nie zdefiniowana";
}

Tfigura::Tfigura(string n)
{
    nazwa=n;
}


Tfigura::~Tfigura()
{
    //dtor
}

void Tfigura::info(){
    cout<<"Figura : "<<nazwa<<endl;
}

void Tfigura::rysuj(){
    cout<<"rysuje "<<nazwa<<endl;
}

float Tfigura::pole(){
    return 0;
}

float Tfigura::obwod(){
    return 0;
}

void Tfigura::wyswietl(){
    info();
    rysuj();
    cout<<"Pole = "<<pole()<<endl;
    cout<<"Obwod = "<<obwod()<<endl;
}
